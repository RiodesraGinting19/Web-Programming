<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>RIO DESRA GINTING</title>
</head>

<body>
    <h1>Tugas 4</h1>

    <script>
        const pi = 3.14
        var r = 7

        for (var i = 0; i < r; i++) {
            //r = jari-jari
            var r = r;
            //l = luas
            var l = pi * r * r;
            //k = keliling
            var k = 2 * pi * r;

            console.log("jari-jari sebuah lingkaran adalah : "+ r);
            console.log("Memiliki luas : "+ l);
            console.log("dengan keliling : "+ k);
        }

    </script>

</body>

</html>