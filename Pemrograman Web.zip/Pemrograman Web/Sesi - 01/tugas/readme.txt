1. Cara menjalankan web
2. Jika memakai extensi .php
    - jalankan perintah php S localhost:2222
    - bisa menggunakan live server
    
3. Jika memakai extensi .html
    - open index.html
4. Alasan mengikuti ->  web programmer